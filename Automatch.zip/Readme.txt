[Automatch - 실행 안내]

1. 프로젝트 설명
사용자가 풋살 매치를 예약하고 이에 따라 자동으로 팀 배정을 해주는 웹 시스템
Spring Boot, JPA, MySQL, Thymeleaf 기반

- 회원가입 및 로그인 (Member, Manager, Admin 권한 분리)
- 회원: 매치 신청, 매치 확인 및 평가
- 매니저: 경기 승인 요청 (참가 인원 12명 이상 시 사용 신청 가능)
- 관리자: 모든 회원, 매치 정보 조회 및 승인

※ 모든 사용자 역할은 로그인 시 자동 구분

2. 실행 환경
- 운영체제: Windows 10 이상
- Java: JDK 17 이상
- Gradle: 7.x 이상 (Wrapper 포함되어 있음)
- MySQL: 8.x (3306 포트 기준)

※ IntelliJ

데이터베이스 설정  
- MySQL 실행 후, 다음 계정을 생성합니다:

  사용자명: username  
  비밀번호: password

- 다음 SQL을 입력하여 DB 및 사용자 생성:

  CREATE DATABASE automatch DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

  CREATE USER 'username'@'localhost' IDENTIFIED BY 'password';  
  GRANT ALL PRIVILEGES ON automatch.* TO 'username'@'localhost';  
  FLUSH PRIVILEGES;

- `src/main/resources/application.properties` 파일에서 다음 두 줄을 본인이 설정한 계정 정보에 맞게 수정합니다:

  ```properties
  spring.datasource.username=username
  spring.datasource.password=password

4. 프로젝트 실행 방법
(1) 소스파일에서 AutomatchApplication 실행

(2) 실행 후 웹 브라우저에서 다음 주소로 접속:

   http://localhost:8080

5. 기타 참고사항
- 포트를 외부에서 접속하고 싶다면 ngrok 사용 가능:
   ngrok http 8080

6. 사용 방법 예시

1) 브라우저에서 http://localhost:8080 접속 후, 회원가입 또는 로그인

(2) 권한에 따라 다음 기능을 사용할 수 있습니다:

- [회원(Member)]
  - 매치 목록 확인
  - 새 매치 신청
  - 참가한 매치에서 팀원 평가

- [매니저(Manager)]
Id : manager1
passwd : pass1234
  - 매치 참가 인원이 12명 이상일 경우, 경기장 승인 요청 가능

- [관리자(Admin)]
Id : admin
passwd : admin123
  - 전체 회원 목록 확인
  - 전체 매치 목록 및 상세 정보 확인
  - 매니저의 승인 요청 수락 가능