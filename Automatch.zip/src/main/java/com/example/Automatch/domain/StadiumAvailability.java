package com.example.Automatch.domain;

import jakarta.persistence.*;

@Entity
public class StadiumAvailability {

    @Id
    @GeneratedValue
    private Long id;

    private String region;
    private String dayOfWeek;
    private String time;

    private boolean approved = false;

    @ManyToOne
    private Manager manager;

    // 기본 생성자
    public StadiumAvailability() {}

    // Getter & Setter
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(String dayOfWeek) { this.dayOfWeek = dayOfWeek; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public boolean isApproved() { return approved; }
    public void setApproved(boolean approved) { this.approved = approved; }

    public Manager getManager() { return manager; }
    public void setManager(Manager manager) { this.manager = manager; }
}
