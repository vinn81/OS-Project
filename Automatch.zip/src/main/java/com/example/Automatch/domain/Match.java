package com.example.Automatch.domain;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Match {

    @Id
    @GeneratedValue
    private Long id;

    private String dayOfWeek;   // 월, 화, ...
    private String time;        // 09:00, 11:00, ...
    private String region;      // 사용자 region
    private String skillLevel;  // 사용자 skillLevel

    @ManyToMany
    private List<Member> participants = new ArrayList<>();

    private boolean confirmed = false;

    // 기본 생성자
    public Match() {}

    public Match(String dayOfWeek, String time, String region, String skillLevel) {
        this.dayOfWeek = dayOfWeek;
        this.time = time;
        this.region = region;
        this.skillLevel = skillLevel;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(String skillLevel) {
        this.skillLevel = skillLevel;
    }

    public List<Member> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Member> participants) {
        this.participants = participants;
    }

    public boolean isConfirmed() { return confirmed; }
    public void setConfirmed(boolean confirmed) { this.confirmed = confirmed; }
}
