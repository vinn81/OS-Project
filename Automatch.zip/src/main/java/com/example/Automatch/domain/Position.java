package com.example.Automatch.domain;

public enum Position {
    FW, MF, DF, GK
}
