package com.example.Automatch.domain;

import jakarta.persistence.*;

@Entity
public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 평가자
    @ManyToOne(optional = false)
    private Member evaluator;

    // 피평가자
    @ManyToOne(optional = false)
    private Member evaluatee;

    // 어떤 경기에서 평가했는지
    @ManyToOne(optional = false)
    private Match match;

    // 점수 (1~5)
    private int score;

    public Evaluation() {}

    public Evaluation(Member evaluator, Member evaluatee, Match match, int score) {
        this.evaluator = evaluator;
        this.evaluatee  = evaluatee;
        this.match      = match;
        this.score      = score;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Member getEvaluator() {
        return evaluator;
    }

    public void setEvaluator(Member evaluator) {
        this.evaluator = evaluator;
    }

    public Member getEvaluatee() {
        return evaluatee;
    }

    public void setEvaluatee(Member evaluatee) {
        this.evaluatee = evaluatee;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
// getters & setters ...
}
