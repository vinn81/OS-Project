package com.example.Automatch.security;

import com.example.Automatch.domain.Manager;
import com.example.Automatch.repository.ManagerRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class ManagerUserDetailsService implements UserDetailsService {

    private final ManagerRepository managerRepo;

    public ManagerUserDetailsService(ManagerRepository managerRepo) {
        this.managerRepo = managerRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Manager manager = managerRepo.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("해당 매니저를 찾을 수 없습니다: " + username));
        return new ManagerUserDetails(manager);
    }
}
