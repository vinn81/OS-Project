package com.example.Automatch.security;

import org.springframework.context.annotation.*;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider userAuthProvider(
            UniversalUserDetailsService uds,
            PasswordEncoder pw) {
        DaoAuthenticationProvider p = new DaoAuthenticationProvider();
        p.setUserDetailsService(uds);
        p.setPasswordEncoder(pw);
        return p;
    }

    @Bean
    public DaoAuthenticationProvider adminAuthProvider(
            AdminUserDetailsService ads,
            PasswordEncoder pw) {
        DaoAuthenticationProvider p = new DaoAuthenticationProvider();
        p.setUserDetailsService(ads);
        p.setPasswordEncoder(pw);
        return p;
    }

    @Bean
    public DaoAuthenticationProvider managerAuthProvider(
            ManagerUserDetailsService mds,
            PasswordEncoder pw) {
        DaoAuthenticationProvider p = new DaoAuthenticationProvider();
        p.setUserDetailsService(mds);
        p.setPasswordEncoder(pw);
        return p;
    }

    // 매니저 전용 필터 체인
    @Bean
    @Order(1)
    public SecurityFilterChain managerFilterChain(
            HttpSecurity http,
            DaoAuthenticationProvider managerAuthProvider
    ) throws Exception {
        http
                .securityMatcher("/manager/**", "/login/manager")
                .csrf(csrf -> csrf.disable())
                .authenticationProvider(managerAuthProvider)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login/manager").permitAll()
                        .requestMatchers("/manager/**").hasRole("MANAGER")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login/manager")
                        .loginProcessingUrl("/login/manager")
                        .defaultSuccessUrl("/manager/form", true)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout/manager")
                        .logoutSuccessUrl("/login/manager")
                        .permitAll()
                );
        return http.build();
    }

    // 사용자 및 관리자용 필터 체인
    @Bean
    @Order(2)
    public SecurityFilterChain userAndAdminFilterChain(
            HttpSecurity http,
            DaoAuthenticationProvider userAuthProvider,
            DaoAuthenticationProvider adminAuthProvider,
            AuthenticationSuccessHandler successHandler
    ) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authenticationProvider(adminAuthProvider)
                .authenticationProvider(userAuthProvider)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/", "/login", "/signup", "/css/**", "/js/**", "/images/**").permitAll()
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        .requestMatchers("/match/**").hasAnyRole("USER", "ADMIN")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .successHandler(successHandler)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")
                        .permitAll()
                );
        return http.build();
    }

    // 관리자, 사용자, 매니저 구분 로그인 성공 후 라우팅
    @Bean
    public AuthenticationSuccessHandler successHandler() {
        return (req, res, auth) -> {
            boolean isAdmin = auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
            boolean isManager = auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_MANAGER"));

            if (isAdmin) {
                res.sendRedirect("/admin/home");
            } else if (isManager) {
                res.sendRedirect("/manager/form");
            } else {
                res.sendRedirect("/home");
            }
        };
    }
}
