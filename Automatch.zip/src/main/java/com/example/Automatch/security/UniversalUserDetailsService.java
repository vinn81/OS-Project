package com.example.Automatch.security;

import com.example.Automatch.domain.Admin;
import com.example.Automatch.domain.Member;
import com.example.Automatch.domain.Manager;
import com.example.Automatch.repository.AdminRepository;
import com.example.Automatch.repository.MemberRepository;
import com.example.Automatch.repository.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UniversalUserDetailsService implements UserDetailsService {

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private ManagerRepository managerRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // 1. 일반 사용자
        Optional<Member> memberOpt = memberRepository.findByUsername(username);
        if (memberOpt.isPresent()) {
            return new CustomUserDetails(memberOpt.get());
        }

        // 2. 관리자
        Optional<Admin> adminOpt = adminRepository.findByUsername(username);
        if (adminOpt.isPresent()) {
            return new AdminUserDetails(adminOpt.get());
        }

        // 3. 매니저
        Optional<Manager> managerOpt = managerRepository.findByUsername(username);
        if (managerOpt.isPresent()) {
            return new ManagerUserDetails(managerOpt.get());
        }

        throw new UsernameNotFoundException("사용자, 관리자 또는 매니저를 찾을 수 없습니다: " + username);
    }
}
