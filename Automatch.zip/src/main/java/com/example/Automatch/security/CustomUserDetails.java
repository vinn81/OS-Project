package com.example.Automatch.security;

import com.example.Automatch.domain.Member;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class CustomUserDetails implements UserDetails {

    private final Member member;

    public CustomUserDetails(Member member) {
        this.member = member;
    }

    /**
     * 여기가 핵심입니다!
     * Member 엔티티의 role 필드를 읽어서 ROLE_ 접두사를 붙여야
     * Spring Security 의 hasRole 검사에 통과합니다.
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        String role = member.getRole();
        if (role == null || role.isBlank()) {
            role = "USER";  // 혹시 null 이면 기본 USER로
        }
        return List.of(new SimpleGrantedAuthority("ROLE_" + role));
    }

    @Override
    public String getPassword() {
        return member.getPassword();
    }

    @Override
    public String getUsername() {
        return member.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    // 원본 Member 객체가 필요할 때 꺼내 쓰세요
    public Member getMember() {
        return member;
    }
}
