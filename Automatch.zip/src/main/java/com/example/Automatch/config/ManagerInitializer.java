package com.example.Automatch.config;

import com.example.Automatch.domain.Manager;
import com.example.Automatch.repository.ManagerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class ManagerInitializer {

    @Bean
    public CommandLineRunner initManager(
            ManagerRepository managerRepository,
            PasswordEncoder passwordEncoder) {
        return args -> {
            if (managerRepository.findByUsername("manager1").isEmpty()) {
                Manager manager = new Manager();
                manager.setUsername("manager1");
                manager.setPassword(passwordEncoder.encode("pass1234"));
                manager.setRegion("서울");
                manager.setRole("ROLE_MANAGER");
                managerRepository.save(manager);
                System.out.println("✅ 기본 매니저 계정 생성: manager1 / pass1234");
            }
        };
    }
}
