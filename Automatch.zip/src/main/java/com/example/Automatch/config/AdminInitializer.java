package com.example.Automatch.config;

import com.example.Automatch.domain.Admin;
import com.example.Automatch.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminInitializer implements CommandLineRunner {

    private final AdminRepository repo;
    private final PasswordEncoder encoder;

    @Autowired
    public AdminInitializer(AdminRepository repo,
                            PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) throws Exception {
        if (repo.count() == 0) {
            Admin admin = new Admin();
            admin.setUsername("admin");
            admin.setPassword(encoder.encode("admin123"));
            repo.save(admin);
            System.out.println("==> 초기 관리자 계정 생성: admin / admin123");
        }
    }
}
