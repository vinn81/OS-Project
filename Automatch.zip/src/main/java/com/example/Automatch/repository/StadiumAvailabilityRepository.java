package com.example.Automatch.repository;

import com.example.Automatch.domain.StadiumAvailability;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StadiumAvailabilityRepository extends JpaRepository<StadiumAvailability, Long> {
    List<StadiumAvailability> findByApprovedFalse();
    List<StadiumAvailability> findByRegion(String region);
}
