package com.example.Automatch.repository;

import com.example.Automatch.domain.Match;
import com.example.Automatch.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MatchRepository extends JpaRepository<Match, Long> {

    /**
     * 이미 생성된 동일 스케줄 + 지역 + 실력의 매치 조회
     */
    Optional<Match> findByDayOfWeekAndTimeAndRegionAndSkillLevel(String dayOfWeek, String time, String region, String skillLevel);

    /**
     * 특정 회원이 참가한 경기 목록
     */
    List<Match> findByParticipantsContaining(Member member);

    /**
     * 전체 매치 조회 (관리자/목록용 등)
     */
    List<Match> findAll();
}
