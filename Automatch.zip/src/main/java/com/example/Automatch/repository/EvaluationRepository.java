package com.example.Automatch.repository;

import com.example.Automatch.domain.Evaluation;
import com.example.Automatch.domain.Member;
import com.example.Automatch.domain.Match;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EvaluationRepository extends JpaRepository<Evaluation, Long> {
    boolean existsByEvaluatorAndEvaluateeAndMatch(Member evaluator, Member evaluatee, Match match);
}
