package com.example.Automatch.controller;

import com.example.Automatch.domain.Member;
import com.example.Automatch.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Arrays;

@Controller
public class AuthController {

    private final MemberService memberService;

    @Autowired
    public AuthController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @GetMapping("/signup")
    public String signupForm(Model model) {
        model.addAttribute("regions", Arrays.asList("서울", "대구", "부산"));
        model.addAttribute("skillLevels", Arrays.asList("A", "B", "C"));
        model.addAttribute("positions",   Arrays.asList("GK", "DF", "MF", "FW"));
        model.addAttribute("member", new Member());
        return "signup";
    }

    @PostMapping("/signup")
    public String signupSubmit(@ModelAttribute Member member) {
        memberService.register(member);
        return "redirect:/login";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }
}
