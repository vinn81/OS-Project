package com.example.Automatch.controller;

import com.example.Automatch.domain.Match;
import com.example.Automatch.domain.StadiumAvailability;
import com.example.Automatch.repository.MatchRepository;
import com.example.Automatch.repository.MemberRepository;
import com.example.Automatch.repository.StadiumAvailabilityRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final MatchRepository matchRepository;
    private final MemberRepository memberRepository;
    private final StadiumAvailabilityRepository stadiumAvailabilityRepository;

    public AdminController(MatchRepository matchRepository,
                           MemberRepository memberRepository,
                           StadiumAvailabilityRepository stadiumAvailabilityRepository) {
        this.matchRepository = matchRepository;
        this.memberRepository = memberRepository;
        this.stadiumAvailabilityRepository = stadiumAvailabilityRepository;
    }

    /**
     * 관리자 홈 화면
     */
    @GetMapping("/home")
    public String adminHome(Model model) {
        model.addAttribute("totalMatches", matchRepository.count());
        model.addAttribute("totalMembers", memberRepository.count());
        return "admin_home";
    }

    /**
     * 전체 매치 목록
     */
    @GetMapping("/matches")
    public String matchList(Model model) {
        model.addAttribute("matches", matchRepository.findAll());
        return "admin_match_list";
    }

    /**
     * 매치 상세 보기
     */
    @GetMapping("/matches/{id}")
    public String matchDetail(@PathVariable Long id, Model model) {
        Match match = matchRepository.findById(id).orElseThrow();
        model.addAttribute("match", match);
        return "admin_match_detail";
    }

    /**
     * 매치 삭제
     */
    @PostMapping("/matches/{id}/delete")
    public String deleteMatch(@PathVariable Long id) {
        matchRepository.deleteById(id);
        return "redirect:/admin/matches";
    }

    /**
     * 전체 회원 목록
     */
    @GetMapping("/members")
    public String memberList(Model model) {
        model.addAttribute("members", memberRepository.findAll());
        return "admin_member_list";
    }

    /**
     * 매니저가 등록한 승인 대기 슬롯 목록
     */
    @GetMapping("/slots")
    public String showPendingSlots(Model model) {
        List<StadiumAvailability> pendingSlots = stadiumAvailabilityRepository.findByApprovedFalse();
        model.addAttribute("pendingSlots", pendingSlots);
        return "admin_slot_approval";
    }

    /**
     * 슬롯 승인 → 매치 생성
     */
    @PostMapping("/slots/approve/{id}")
    public String approveSlot(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        StadiumAvailability slot = stadiumAvailabilityRepository.findById(id)
                .orElseThrow();

        slot.setApproved(true);
        stadiumAvailabilityRepository.save(slot);

        Match match = new Match(slot.getDayOfWeek(), slot.getTime(), slot.getRegion(), "A");
        matchRepository.save(match);

        redirectAttributes.addFlashAttribute("message", "예약이 확정되었습니다.");

        return "redirect:/admin/home";
    }
}
