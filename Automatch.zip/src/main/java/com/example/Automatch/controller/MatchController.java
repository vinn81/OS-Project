package com.example.Automatch.controller;

import com.example.Automatch.domain.Match;
import com.example.Automatch.domain.Member;
import com.example.Automatch.security.CustomUserDetails;
import com.example.Automatch.service.EvaluationService;
import com.example.Automatch.service.MatchService;
import com.example.Automatch.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.LinkedHashMap;

@Controller
@RequestMapping("/match")
public class MatchController {

    private final MatchService matchService;
    private final MemberService memberService;
    private final EvaluationService evaluationService;

    @Autowired
    public MatchController(MatchService matchService,
                           MemberService memberService,
                           EvaluationService evaluationService) {
        this.matchService = matchService;
        this.memberService = memberService;
        this.evaluationService = evaluationService;
    }

    // 경기 예약 페이지
    @GetMapping("/reserve")
    public String reserveForm(@AuthenticationPrincipal CustomUserDetails user,
                              Model model) {
        model.addAttribute("daysOfWeek",
                Arrays.asList("월", "화", "수", "목", "금", "토", "일"));

        List<String> timeSlots = new ArrayList<>();
        for (int h = 9; h <= 21; h += 2) {
            timeSlots.add(String.format("%02d:00 ~ %02d:00", h, h + 2));
        }
        model.addAttribute("timeSlots", timeSlots);

        Member m = memberService.findByUsername(user.getUsername());
        model.addAttribute("userRegion", m.getRegion());
        model.addAttribute("availableMatches", matchService.getAvailableMatches());

        return "match_reserve";
    }

    // 경기 예약 처리
    @PostMapping("/reserve")
    public String reserveSubmit(@AuthenticationPrincipal CustomUserDetails user,
                                @RequestParam("dayOfWeek") String dayOfWeek,
                                @RequestParam("time") String time) {
        Member m = memberService.findByUsername(user.getUsername());
        String region = m.getRegion();
        String skillLevel = m.getSkillLevel(); // 실력 기준 추가
        matchService.reserveMatch(m, dayOfWeek, time, region, skillLevel);
        return "redirect:/match/my";
    }

    // 내가 참가한 경기
    @GetMapping("/my")
    public String myMatches(@AuthenticationPrincipal CustomUserDetails user,
                            Model model) {
        Member m = memberService.findByUsername(user.getUsername());
        model.addAttribute("myMatches", matchService.findMatchesByMember(m));
        return "match_my";
    }

    // 평가 폼
    @GetMapping("/evaluate")
    public String evaluateForm(@AuthenticationPrincipal CustomUserDetails user,
                               Model model) {
        Member me = memberService.findByUsername(user.getUsername());
        List<Match> myMatches = matchService.findMatchesByMember(me);

        Map<Match, List<Member>> toEvaluateMap = new LinkedHashMap<>();
        for (Match match : myMatches) {
            List<Member> peers = new ArrayList<>();
            for (Member p : match.getParticipants()) {
                if (!p.getUsername().equals(me.getUsername()) &&
                        !evaluationService.existsByEvaluatorAndEvaluateeAndMatch(me, p, match)) {
                    peers.add(p);
                }
            }
            if (!peers.isEmpty()) {
                toEvaluateMap.put(match, peers);
            }
        }

        model.addAttribute("toEvaluateMap", toEvaluateMap);
        return "match_evaluate";
    }

    // 평가 처리
    @PostMapping("/evaluate")
    public String evaluateSubmit(@AuthenticationPrincipal CustomUserDetails user,
                                 @RequestParam("matchId") Long matchId,
                                 @RequestParam("evaluatee") Long evaluateeId,
                                 @RequestParam("score") int score) {
        Member me = memberService.findByUsername(user.getUsername());
        Member peer = memberService.findById(evaluateeId);
        evaluationService.evaluatePlayer(me, matchId, peer, score);
        return "redirect:/match/evaluate";
    }
}
