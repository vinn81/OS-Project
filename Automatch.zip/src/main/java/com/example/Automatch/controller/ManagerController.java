package com.example.Automatch.controller;

import com.example.Automatch.domain.Manager;
import com.example.Automatch.domain.StadiumAvailability;
import com.example.Automatch.repository.ManagerRepository;
import com.example.Automatch.repository.StadiumAvailabilityRepository;
import com.example.Automatch.security.ManagerUserDetails;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/manager")
public class ManagerController {

    private final StadiumAvailabilityRepository slotRepo;
    private final ManagerRepository managerRepo;

    public ManagerController(StadiumAvailabilityRepository slotRepo,
                             ManagerRepository managerRepo) {
        this.slotRepo = slotRepo;
        this.managerRepo = managerRepo;
    }

    @GetMapping("/form")
    public String showForm(Model model,
                           @AuthenticationPrincipal ManagerUserDetails user) {
        Manager manager = user.getManager();
        List<StadiumAvailability> mySlots = slotRepo.findByRegion(manager.getRegion());

        model.addAttribute("days", List.of("월", "화", "수", "목", "금", "토", "일"));
        model.addAttribute("times", List.of(
                "09:00 ~ 11:00", "11:00 ~ 13:00",
                "13:00 ~ 15:00", "15:00 ~ 17:00"
        ));
        model.addAttribute("mySlots", mySlots);
        model.addAttribute("managerRegion", manager.getRegion());
        return "manager_availability_form";
    }

    @PostMapping("/submit")
    public String submitAvailability(@AuthenticationPrincipal ManagerUserDetails user,
                                     @RequestParam String region,
                                     @RequestParam String dayOfWeek,
                                     @RequestParam String time) {
        Manager manager = managerRepo.findByUsername(user.getUsername()).orElseThrow();

        StadiumAvailability slot = new StadiumAvailability();
        slot.setDayOfWeek(dayOfWeek);
        slot.setTime(time);
        slot.setRegion(region); // 선택된 지역 사용
        slot.setManager(manager);
        slot.setApproved(false);

        slotRepo.save(slot);
        return "redirect:/manager/form";
    }

}
