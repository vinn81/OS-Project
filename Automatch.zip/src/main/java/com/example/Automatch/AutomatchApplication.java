package com.example.Automatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomatchApplication.class, args);
		System.out.println("Test");
	}
}
