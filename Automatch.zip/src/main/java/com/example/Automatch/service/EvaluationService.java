package com.example.Automatch.service;

import com.example.Automatch.domain.Evaluation;
import com.example.Automatch.domain.Member;
import com.example.Automatch.domain.Match;
import com.example.Automatch.repository.EvaluationRepository;
import com.example.Automatch.repository.MatchRepository;
import com.example.Automatch.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EvaluationService {

    private final EvaluationRepository evalRepo;
    private final MatchRepository       matchRepo;
    private final MemberRepository      memberRepo;

    @Autowired
    public EvaluationService(EvaluationRepository evalRepo,
                             MatchRepository matchRepo,
                             MemberRepository memberRepo) {
        this.evalRepo   = evalRepo;
        this.matchRepo  = matchRepo;
        this.memberRepo = memberRepo;
    }

    /**
     * evaluator가 이미 evaluatee를 해당 match에서 평가했는지 여부
     */
    public boolean existsByEvaluatorAndEvaluateeAndMatch(Member evaluator,
                                                         Member evaluatee,
                                                         Match match) {
        return evalRepo.existsByEvaluatorAndEvaluateeAndMatch(evaluator, evaluatee, match);
    }

    /**
     * evaluator가 evaluatee를 match에서 평가
     * -> 저장 후 evaluatee의 평균 평점, 평가 수를 업데이트
     */
    public void evaluatePlayer(Member evaluator,
                               Long matchId,
                               Member evaluatee,
                               int score) {
        Match match = matchRepo.findById(matchId)
                .orElseThrow(() -> new IllegalArgumentException("매치를 찾을 수 없습니다: " + matchId));

        // 중복 평가 방지
        if (existsByEvaluatorAndEvaluateeAndMatch(evaluator, evaluatee, match)) {
            return;
        }

        Evaluation ev = new Evaluation(evaluator, evaluatee, match, score);
        evalRepo.save(ev);

        float oldAvg   = evaluatee.getEvaluationScore();    // 이미 float 타입
        int   oldCount = evaluatee.getEvaluationCount();

        int   newCount = oldCount + 1;
        float newAvg   = (float)((oldAvg * oldCount + score) / (double)newCount);

        evaluatee.setEvaluationCount(newCount);
        evaluatee.setEvaluationScore(newAvg);
        memberRepo.save(evaluatee);
    }
}
