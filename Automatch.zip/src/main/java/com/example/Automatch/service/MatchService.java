// src/main/java/com/example/Automatch/service/MatchService.java
package com.example.Automatch.service;

import com.example.Automatch.domain.Match;
import com.example.Automatch.domain.Member;
import com.example.Automatch.repository.MatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MatchService {

    private final MatchRepository repo;

    @Autowired
    public MatchService(MatchRepository repo) {
        this.repo = repo;
    }

    /**
     * 예약 가능한 모든 경기(스케줄별로 하나만) 조회
     */
    public List<Match> getAvailableMatches() {
        return repo.findAll();
    }

    /**
     * 특정 회원이 참가한 경기 목록 조회
     */
    public List<Match> findMatchesByMember(Member member) {
        return repo.findByParticipantsContaining(member);
    }

    /**
     * 경기 예약 처리
     * - 동일 요일·시간·지역·실력 매치가 있으면 거기에 참여자 추가
     * - 없으면 새로운 매치 생성
     */
    public void reserveMatch(Member member,
                             String dayOfWeek,
                             String time,
                             String region,
                             String skillLevel) {

        Optional<Match> existingMatch = repo.findByDayOfWeekAndTimeAndRegionAndSkillLevel(dayOfWeek, time, region, skillLevel);

        Match match = existingMatch.orElseGet(() -> {
            Match newMatch = new Match(dayOfWeek, time, region, skillLevel);
            return repo.save(newMatch);
        });

        if (!match.getParticipants().contains(member)) {
            match.getParticipants().add(member);
            repo.save(match);
        }
    }

    /**
     * 평가가 필요한 경기 목록 조회
     */
    public List<Match> findMatchesForEvaluation(Member member) {
        return repo.findByParticipantsContaining(member);
    }

    /**
     * 경기 평가 처리 (예시: 콘솔 출력만)
     */
    public void evaluateMatch(Member member,
                              Long matchId,
                              int score) {
        Match match = repo.findById(matchId)
                .orElseThrow(() -> new IllegalArgumentException("해당 ID의 경기를 찾을 수 없습니다: " + matchId));

        // TODO: 실제 평가 저장 로직 구현
        System.out.printf("Member[%s] evaluated Match[%d] with score %d%n",
                member.getUsername(), match.getId(), score);
    }
}