package com.example.Automatch.service;

import com.example.Automatch.domain.Member;
import com.example.Automatch.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class MemberService {

    private final MemberRepository memberRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public MemberService(MemberRepository memberRepository,
                         PasswordEncoder passwordEncoder) {
        this.memberRepository = memberRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * 회원 가입 처리
     * - 비밀번호 암호화
     * - 기본 ROLE_USER 설정
     */
    public void register(Member member) {
        member.setRole("USER");
        String raw = member.getPassword();
        member.setPassword(passwordEncoder.encode(raw));
        memberRepository.save(member);
    }

    /**
     * 사용자명으로 회원 조회
     */
    public Member findByUsername(String username) {
        return memberRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("유저를 찾을 수 없습니다: " + username));
    }

    /**
     * ID로 회원 조회
     */
    public Member findById(Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 ID의 회원을 찾을 수 없습니다: " + id));
    }
}
